// data.ts
export const products = [
  {
    id: 1,
    name: "Vintage Camera",
    price: 45,
    description: "A classic film camera in great condition.",
  },
  {
    id: 2,
    name: "Leather Bag",
    price: 30,
    description: "Handcrafted leather bag, perfect for daily use.",
  },
  {
    id: 3,
    name: "Wooden Desk Lamp",
    price: 25,
    description: "Minimalist wooden lamp to brighten your workspace.",
  },
];