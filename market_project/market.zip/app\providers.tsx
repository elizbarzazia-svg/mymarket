'use client';

import { ReactNode } from 'react';
import { AuthProvider } from '../lib/AuthContext';
import { LanguageProvider } from '../lib/LanguageContext';
import { FavoritesProvider } from '@/lib/FavoritesContext';
import { CartProvider } from '@/lib/CartContext';

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <LanguageProvider>
        <FavoritesProvider>
          <CartProvider>
            {children}
          </CartProvider>
        </FavoritesProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}