'use client';

import { useRef, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { useAuth } from '../../lib/AuthContext';
import { useLanguage } from '../../lib/LanguageContext';
import { CATEGORIES } from '../../lib/categories';
import { VIP_TIERS } from '../../lib/vip';

type Errors = {
  name?: boolean;
  price?: boolean;
  description?: boolean;
  photo?: boolean;
  phone?: boolean;
  category?: boolean;
};

export default function SellerPage() {
  const { user } = useAuth();
  const { t } = useLanguage();

  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [phone, setPhone] = useState('');
  const [category, setCategory] = useState('');
  const [isVip, setIsVip] = useState(false);
  const [vipTier, setVipTier] = useState<(typeof VIP_TIERS)[number]['key']>('day');

  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  const [errors, setErrors] = useState<Errors>({});
  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const tierLabel = (key: (typeof VIP_TIERS)[number]['key']) => {
    if (key === 'day') return t('seller.tierDay');
    if (key === 'week') return t('seller.tierWeek');
    return t('seller.tierMonth');
  };

  const handleFile = (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) return;
    setPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
    setErrors((prev) => ({ ...prev, photo: false }));
  };

  const validate = (): Errors => ({
    name: name.trim() === '',
    price: price.trim() === '',
    description: description.trim() === '',
    photo: !photoFile,
    phone: phone.trim() === '',
    category: category.trim() === '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.values(next).some(Boolean)) return;

    setSubmitting(true);
    setStatus('idle');

    try {
      let imageUrl: string | null = null;

      if (photoFile) {
        const ext = photoFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
        const { error: uploadError } = await supabase.storage
          .from('product-images')
          .upload(fileName, photoFile);

        if (uploadError) throw uploadError;

        const { data: publicUrlData } = supabase.storage
          .from('product-images')
          .getPublicUrl(fileName);
        imageUrl = publicUrlData.publicUrl;
      }

      const vipExpiresAt = isVip
        ? (() => {
            const tier = VIP_TIERS.find((tr) => tr.key === vipTier)!;
            const d = new Date();
            d.setDate(d.getDate() + tier.days);
            return d.toISOString();
          })()
        : null;

      const { error } = await supabase.from('products').insert([
        {
          name,
          price: Number(price),
          description,
          is_vip: isVip,
          vip_expires_at: vipExpiresAt,
          image_url: imageUrl,
          user_id: user?.id,
          phone,
          category,
        },
      ]);

      if (error) throw error;

      setStatus('success');
      setName('');
      setPrice('');
      setDescription('');
      setPhone('');
      setCategory('');
      setIsVip(false);
      setVipTier('day');
      setPhotoFile(null);
      setPhotoPreview(null);
      setErrors({});
    } catch (err: any) {
      setErrorMsg(err.message ?? 'Unknown error');
      setStatus('error');
    } finally {
      setSubmitting(false);
    }
  };

  const fieldClass = (hasError?: boolean) =>
    `bg-input-bg border rounded-lg px-4 py-3 text-sm outline-none transition-colors placeholder:text-text-muted/60 ${
      hasError
        ? 'border-red-500/70 focus:border-red-500'
        : 'border-border-subtle focus:border-vip-border'
    }`;

  return (
    <div className="bg-brand-bg min-h-screen text-text-primary">
      <div className="max-w-2xl mx-auto px-6 pt-16 pb-24">
        <div className="mb-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">{t('seller.title')}</h1>
          <p className="text-text-muted">{t('seller.subtitle')}</p>
        </div>

        <form
          onSubmit={handleSubmit}
          noValidate
          className="bg-card-bg border border-border-subtle rounded-2xl p-8 flex flex-col gap-6"
        >
          {/* Photo upload */}
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium text-text-muted">
              {t('seller.photo')} <span className="text-vip-border font-bold">*</span>
            </label>

            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragActive(false);
                handleFile(e.dataTransfer.files?.[0]);
              }}
              className={`relative rounded-lg border-2 border-dashed transition-colors overflow-hidden ${
                errors.photo
                  ? 'border-red-500/70'
                  : dragActive
                  ? 'border-vip-border bg-vip-border/5'
                  : 'border-border-subtle'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleFile(e.target.files?.[0])}
              />
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={(e) => handleFile(e.target.files?.[0])}
              />

              {photoPreview ? (
                <div className="relative w-full aspect-square bg-input-bg">
                  <img src={photoPreview} alt="preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => {
                      setPhotoFile(null);
                      setPhotoPreview(null);
                    }}
                    className="absolute top-2 right-2 bg-black/70 hover:bg-black text-white text-xs rounded-full w-7 h-7 flex items-center justify-center transition-colors"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center gap-4 p-10">
                  <svg className="w-8 h-8 text-text-muted" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14M4 8h16M4 4h16v16H4V4z"
                    />
                  </svg>
                  <p className="text-sm text-text-muted text-center">{t('seller.dragDropText')}</p>
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => cameraInputRef.current?.click()}
                      className="flex items-center gap-2 bg-vip-border/10 border border-vip-border/40 hover:border-vip-border text-vip-text text-sm font-medium rounded-lg px-4 py-2 transition-colors"
                    >
                      {t('seller.takePhoto')}
                    </button>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center gap-2 bg-input-bg border border-border-subtle hover:border-vip-border/50 text-text-primary text-sm font-medium rounded-lg px-4 py-2 transition-colors"
                    >
                      {t('seller.chooseFromGallery')}
                    </button>
                  </div>
                </div>
              )}
            </div>

            {errors.photo && <p className="text-xs text-red-400">{t('seller.photoRequired')}</p>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium text-text-muted">
              {t('seller.name')} <span className="text-vip-border font-bold">*</span>
            </label>
            <input
              type="text"
              placeholder={t('seller.namePlaceholder')}
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (e.target.value.trim()) setErrors((p) => ({ ...p, name: false }));
              }}
              className={fieldClass(errors.name)}
            />
            {errors.name && <p className="text-xs text-red-400">{t('seller.nameRequired')}</p>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium text-text-muted">
              {t('seller.price')} <span className="text-vip-border font-bold">*</span>
            </label>
            <input
              type="number"
              min="0"
              placeholder="0.00"
              value={price}
              onChange={(e) => {
                setPrice(e.target.value);
                if (e.target.value.trim()) setErrors((p) => ({ ...p, price: false }));
              }}
              className={fieldClass(errors.price)}
            />
            {errors.price && <p className="text-xs text-red-400">{t('seller.priceRequired')}</p>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium text-text-muted">
              {t('seller.description')} <span className="text-vip-border font-bold">*</span>
            </label>
            <textarea
              rows={4}
              placeholder={t('seller.descriptionPlaceholder')}
              value={description}
              onChange={(e) => {
                setDescription(e.target.value);
                if (e.target.value.trim()) setErrors((p) => ({ ...p, description: false }));
              }}
              className={`${fieldClass(errors.description)} resize-none`}
            />
            {errors.description && <p className="text-xs text-red-400">{t('seller.descriptionRequired')}</p>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium text-text-muted">
              {t('seller.phone')} <span className="text-vip-border font-bold">*</span>
            </label>
            <input
              type="tel"
              placeholder={t('seller.phonePlaceholder')}
              value={phone}
              onChange={(e) => {
                setPhone(e.target.value);
                if (e.target.value.trim()) setErrors((p) => ({ ...p, phone: false }));
              }}
              className={fieldClass(errors.phone)}
            />
            {errors.phone && <p className="text-xs text-red-400">{t('seller.phoneRequired')}</p>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium text-text-muted">
              {t('seller.category')} <span className="text-vip-border font-bold">*</span>
            </label>
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                if (e.target.value) setErrors((p) => ({ ...p, category: false }));
              }}
              className={`${fieldClass(errors.category)} appearance-none cursor-pointer`}
            >
              <option value="">{t('seller.categoryPlaceholder')}</option>
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
            {errors.category && <p className="text-xs text-red-400">{t('seller.categoryRequired')}</p>}
          </div>

          <div className="flex flex-col gap-3">
            <label className="flex items-center gap-3 cursor-pointer select-none">
              <span className="relative inline-flex items-center">
                <input
                  type="checkbox"
                  checked={isVip}
                  onChange={(e) => setIsVip(e.target.checked)}
                  className="peer sr-only"
                />
                <span className="w-10 h-6 bg-input-bg border border-border-subtle rounded-full peer-checked:bg-vip-border/30 peer-checked:border-vip-border transition-colors" />
                <span className="absolute left-1 top-1 w-4 h-4 bg-text-muted peer-checked:bg-vip-text peer-checked:translate-x-4 rounded-full transition-transform" />
              </span>
              <span className="text-sm text-text-primary">
                {t('seller.markAsVip')} <span className="text-vip-text font-medium">{t('seller.vipItem')}</span>
              </span>
            </label>

            {isVip && (
              <div className="flex flex-col gap-2 pl-1">
                {VIP_TIERS.map((tr) => (
                  <button
                    key={tr.key}
                    type="button"
                    onClick={() => setVipTier(tr.key)}
                    className={`flex items-center justify-between rounded-lg border px-4 py-2.5 text-sm text-left transition-colors ${
                      vipTier === tr.key
                        ? 'border-vip-border bg-vip-border/10'
                        : 'border-border-subtle hover:border-vip-border/40'
                    }`}
                  >
                    <span>{tierLabel(tr.key)}</span>
                    <span className="font-semibold text-vip-text">{tr.price.toFixed(2)} ₾</span>
                  </button>
                ))}
                <p className="text-xs text-text-muted bg-input-bg border border-border-subtle rounded-lg px-3 py-2">
                  {t('seller.testModeNotice')}
                </p>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="mt-2 bg-vip-border text-black font-semibold rounded-lg py-3 hover:opacity-90 disabled:opacity-50 transition-opacity"
          >
            {submitting ? t('seller.submitting') : t('seller.submit')}
          </button>

          {status === 'success' && (
            <p className="text-sm text-center text-emerald-400">{t('seller.successMessage')}</p>
          )}
          {status === 'error' && (
            <p className="text-sm text-center text-red-400">
              {t('seller.errorPrefix')}: {errorMsg}
            </p>
          )}
        </form>
      </div>
    </div>
  );
}