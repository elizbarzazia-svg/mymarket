'use client';

import { Suspense, useEffect, useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { supabase } from '../../lib/supabaseClient';
import { isVipActive } from '../../lib/vip';
import { useLanguage } from '../../lib/LanguageContext';
import FavoriteButton from '../../components/FavoriteButton';
import AddToCartButton from '../../components/AddToCartButton';

type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  is_vip: boolean;
  image_url?: string | null;
  phone?: string | null;
  category?: string | null;
  vip_expires_at?: string | null;
  created_at?: string;
};

type SortOption = 'newest' | 'price_asc' | 'price_desc' | 'vip_first';

const PAGE_SIZE = 9;

function getPageNumbers(current: number, total: number): (number | string)[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const pages: (number | string)[] = [1];
  if (current > 3) pages.push('...');
  const start = Math.max(2, current - 1);
  const end = Math.min(total - 1, current + 1);
  for (let i = start; i <= end; i++) pages.push(i);
  if (current < total - 2) pages.push('...');
  pages.push(total);
  return pages;
}

export default function BuyerPage() {
  return (
    <Suspense fallback={null}>
      <BuyerPageContent />
    </Suspense>
  );
}

function BuyerPageContent() {
  const { t } = useLanguage();
  const router = useRouter();
  const searchParams = useSearchParams();
  const searchQuery = searchParams.get('search') || '';
  const categoryFilter = searchParams.get('category') || '';

  const SORT_LABELS: Record<SortOption, string> = {
    newest: t('buyer.sortNewest'),
    price_asc: t('buyer.sortPriceAsc'),
    price_desc: t('buyer.sortPriceDesc'),
    vip_first: t('buyer.sortVipFirst'),
  };

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState<SortOption>('newest');
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [selected, setSelected] = useState<Product | null>(null);
  const [phoneRevealed, setPhoneRevealed] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      const { data, error } = await supabase.from('products').select('*');
      if (!error && data) setProducts(data as Product[]);
      setLoading(false);
    };
    fetchProducts();
  }, []);

  useEffect(() => {
    if (!selected) return;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelected(null);
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', onKey);
    };
  }, [selected]);

  useEffect(() => {
    setPhoneRevealed(false);
  }, [selected?.id]);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, categoryFilter, sort]);

  const filteredAndSortedProducts = useMemo(() => {
    let list = [...products];

    if (categoryFilter) {
      list = list.filter((p) => p.category === categoryFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
      );
    }

    switch (sort) {
      case 'price_asc':
        return list.sort((a, b) => a.price - b.price);
      case 'price_desc':
        return list.sort((a, b) => b.price - a.price);
      case 'vip_first':
        return list.sort((a, b) => Number(isVipActive(b)) - Number(isVipActive(a)));
      default:
        return list.sort(
          (a, b) =>
            new Date(b.created_at ?? 0).getTime() -
            new Date(a.created_at ?? 0).getTime()
        );
    }
  }, [products, sort, searchQuery, categoryFilter]);

  const totalPages = Math.max(1, Math.ceil(filteredAndSortedProducts.length / PAGE_SIZE));

  const paginatedProducts = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredAndSortedProducts.slice(start, start + PAGE_SIZE);
  }, [filteredAndSortedProducts, currentPage]);

  const clearFilter = (key: 'search' | 'category') => {
    const params = new URLSearchParams(searchParams.toString());
    params.delete(key);
    router.push(params.toString() ? `/buyer?${params.toString()}` : '/buyer');
  };

  const hasActiveFilters = Boolean(searchQuery || categoryFilter);

  return (
    <div className="bg-brand-bg min-h-screen text-text-primary">
      <div className="max-w-7xl mx-auto px-6 pt-16 pb-24">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6 mb-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">{t('buyer.title')}</h1>
            <p className="text-text-muted mt-2">
              {loading
                ? t('buyer.loading')
                : `${filteredAndSortedProducts.length} ${t('buyer.itemsAvailableSuffix')}`}
            </p>
          </div>

          <div className="relative w-full sm:w-64">
            <button
              onClick={() => setDropdownOpen((o) => !o)}
              className="w-full flex items-center justify-between bg-card-bg border border-border-subtle hover:border-vip-border/60 rounded-lg px-4 py-3 text-sm transition-colors"
            >
              <span>{SORT_LABELS[sort]}</span>
              <svg
                className={`w-4 h-4 text-text-muted transition-transform ${
                  dropdownOpen ? 'rotate-180' : ''
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {dropdownOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setDropdownOpen(false)} />
                <div className="absolute z-20 mt-2 w-full bg-card-bg border border-border-subtle rounded-lg overflow-hidden shadow-lg shadow-black/5">
                  {(Object.keys(SORT_LABELS) as SortOption[]).map((option) => (
                    <button
                      key={option}
                      onClick={() => {
                        setSort(option);
                        setDropdownOpen(false);
                      }}
                      className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                        sort === option
                          ? 'bg-vip-border/10 text-vip-text'
                          : 'hover:bg-card-hover text-text-primary'
                      }`}
                    >
                      {SORT_LABELS[option]}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {hasActiveFilters && (
          <div className="flex flex-wrap items-center gap-2 mb-8">
            {searchQuery && (
              <span className="flex items-center gap-2 bg-card-bg border border-border-subtle rounded-full pl-4 pr-2 py-1.5 text-sm">
                {t('buyer.searchLabel')}: „{searchQuery}"
                <button
                  onClick={() => clearFilter('search')}
                  className="w-5 h-5 flex items-center justify-center rounded-full hover:bg-card-hover text-text-muted"
                >
                  ✕
                </button>
              </span>
            )}
            {categoryFilter && (
              <span className="flex items-center gap-2 bg-card-bg border border-border-subtle rounded-full pl-4 pr-2 py-1.5 text-sm">
                {t('buyer.categoryLabel')}: {categoryFilter}
                <button
                  onClick={() => clearFilter('category')}
                  className="w-5 h-5 flex items-center justify-center rounded-full hover:bg-card-hover text-text-muted"
                >
                  ✕
                </button>
              </span>
            )}
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-card-bg border border-border-subtle rounded-xl h-56 animate-pulse" />
            ))}
          </div>
        ) : filteredAndSortedProducts.length === 0 ? (
          <div className="text-center py-24 text-text-muted">
            {hasActiveFilters ? t('buyer.noResultsFiltered') : t('buyer.noItemsYet')}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {paginatedProducts.map((product) => (
                // NOTE: was a <button> — changed to a clickable <div> so the
                // FavoriteButton / AddToCartButton (real <button>s) can nest
                // inside it safely. Nesting <button> inside <button> is
                // invalid HTML and breaks layout/hydration.
                <div
                  key={product.id}
                  onClick={() => setSelected(product)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setSelected(product);
                    }
                  }}
                  className="group relative text-left bg-card-bg border border-border-subtle hover:border-vip-border/50 rounded-xl overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-black/5 cursor-pointer"
                >
                  {product.image_url ? (
                    <div className="relative aspect-video w-full overflow-hidden bg-input-bg">
                      <img
                        src={product.image_url}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-3 right-3 z-10">
                        <FavoriteButton productId={product.id} variant="card" />
                      </div>
                    </div>
                  ) : (
                    <div className="relative aspect-video w-full bg-input-bg flex items-center justify-center text-text-muted text-xs">
                      {t('buyer.noPhoto')}
                      <div className="absolute top-3 right-3 z-10">
                        <FavoriteButton productId={product.id} variant="card" />
                      </div>
                    </div>
                  )}

                  <div className="relative p-6">
                    {isVipActive(product) && (
                      <span className="absolute top-4 right-4 flex items-center gap-1 text-[11px] font-semibold tracking-wide uppercase text-vip-text bg-vip-border/15 border border-vip-border/40 rounded-full px-2.5 py-1">
                        ★ VIP
                      </span>
                    )}

                    <h3 className="text-lg font-semibold mb-1 pr-12 group-hover:text-vip-text transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-text-muted text-sm mb-6 line-clamp-2">{product.description}</p>

                    <div className="flex items-center justify-between pt-4 border-t border-border-subtle">
                      <span className="text-xl font-bold text-emerald-600">{product.price} ₾</span>
                      <div className="flex items-center gap-3">
                        <AddToCartButton
                          product={{
                            id: product.id,
                            name: product.name,
                            price: product.price,
                            image_url: product.image_url ?? null,
                            phone: product.phone ?? null,
                          }}
                          variant="card"
                        />
                        <span className="hidden sm:inline text-sm font-medium text-vip-text opacity-0 group-hover:opacity-100 transition-opacity">
                          {t('buyer.viewDetails')} →
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-10">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="w-9 h-9 flex items-center justify-center rounded-full border border-border-subtle hover:border-vip-border/50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                >
                  ←
                </button>

                {getPageNumbers(currentPage, totalPages).map((page, i) =>
                  page === '...' ? (
                    <span key={`ellipsis-${i}`} className="px-1 text-text-muted text-sm">
                      ...
                    </span>
                  ) : (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page as number)}
                      className={`w-9 h-9 flex items-center justify-center rounded-full text-sm font-medium transition-colors ${
                        currentPage === page
                          ? 'bg-vip-border text-black'
                          : 'border border-border-subtle hover:border-vip-border/50 text-text-primary'
                      }`}
                    >
                      {page}
                    </button>
                  )
                )}

                <button
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="w-9 h-9 flex items-center justify-center rounded-full border border-border-subtle hover:border-vip-border/50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                >
                  →
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {selected && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8"
          onClick={() => setSelected(null)}
        >
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />

          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-card-bg border border-border-subtle rounded-2xl shadow-2xl"
          >
            <button
              onClick={() => setSelected(null)}
              className="absolute top-4 right-4 z-10 w-9 h-9 flex items-center justify-center rounded-full bg-black/60 hover:bg-black text-white transition-colors"
            >
              ✕
            </button>

            {selected.image_url ? (
              <div className="w-full aspect-video bg-input-bg">
                <img src={selected.image_url} alt={selected.name} className="w-full h-full object-cover" />
              </div>
            ) : (
              <div className="w-full aspect-video bg-input-bg flex items-center justify-center text-text-muted">
                {t('buyer.noPhoto')}
              </div>
            )}

            <div className="p-8">
              <div className="flex items-start justify-between gap-4 mb-4">
                <h2 className="text-2xl md:text-3xl font-bold text-text-primary">{selected.name}</h2>
                {isVipActive(selected) && (
                  <span className="shrink-0 flex items-center gap-1 text-xs font-semibold tracking-wide uppercase text-vip-text bg-vip-border/15 border border-vip-border/40 rounded-full px-3 py-1.5">
                    ★ VIP
                  </span>
                )}
              </div>

              {selected.category && (
                <span className="inline-block text-xs font-medium text-text-muted border border-border-subtle rounded-full px-3 py-1 mb-4">
                  {selected.category}
                </span>
              )}

              <p className="text-text-muted leading-relaxed mb-8 whitespace-pre-line">{selected.description}</p>

              {/* Favorite + Add to Cart — grouped together right above the
                  phone-reveal action, as requested */}
              <div className="flex items-center gap-3 mb-6">
                <FavoriteButton productId={selected.id} variant="detail" />
                <AddToCartButton
                  product={{
                    id: selected.id,
                    name: selected.name,
                    price: selected.price,
                    image_url: selected.image_url ?? null,
                    phone: selected.phone ?? null,
                  }}
                  variant="card"
                />
              </div>

              <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
                <span className="text-3xl font-bold text-emerald-600">{selected.price} ₾</span>

                {phoneRevealed && selected.phone ? (
                  <a
                    href={`tel:${selected.phone}`}
                    className="flex items-center gap-2 bg-emerald-600 text-white font-semibold px-6 py-3 rounded-lg hover:opacity-90 transition-opacity"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                      />
                    </svg>
                    {selected.phone}
                  </a>
                ) : (
                  <button
                    onClick={() => setPhoneRevealed(true)}
                    disabled={!selected.phone}
                    className="bg-vip-border text-black font-semibold px-6 py-3 rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {selected.phone ? t('buyer.showPhone') : t('buyer.noPhoneListed')}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}