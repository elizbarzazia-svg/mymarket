'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { supabase } from '../../../lib/supabaseClient';

export default function ProductDetails() {
  const { id } = useParams(); // URL-დან ვიღებთ ნივთის ID-ს
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchProduct() {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', id)
        .single(); // ვიღებთ მხოლოდ ერთ, კონკრეტულ ნივთს

      if (error) console.error("შეცდომა:", error);
      else setProduct(data);
      setLoading(false);
    }
    
    if (id) fetchProduct();
  }, [id]);

  if (loading) return <div>იტვირთება...</div>;
  if (!product) return <div>ნივთი ვერ მოიძებნა.</div>;

  return (
    <div className="p-10 max-w-2xl mx-auto">
      <h1 className="text-4xl font-bold">{product.name}</h1>
      <p className="text-2xl text-green-700 font-bold my-4">{product.price}$</p>
      <p className="text-gray-700 text-lg">{product.description}</p>
      <button className="mt-6 bg-black text-white px-6 py-2 rounded">შეძენა</button>
    </div>
  );
}