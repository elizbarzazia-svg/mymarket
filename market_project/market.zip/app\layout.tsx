import Header from '../components/Header';
import Providers from './providers';
import './globals.css';
import CartDrawer from '@/components/CartDrawer';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers>
          <Header />
          <main>{children}</main>
          <CartDrawer />
        </Providers>
      </body>
    </html>
  );
}